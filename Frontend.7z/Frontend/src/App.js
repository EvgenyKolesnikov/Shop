import Navigation from './component/navigation';

function App() {
  return (
    <div>
        <Navigation />
    </div>
  );
}

export default App;
